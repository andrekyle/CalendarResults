# Exam Results Dashboard PWA

A Progressive Web App for viewing student exam results and analytics.

## Features
- Responsive design
- Offline capability
- Installable on mobile devices
- Real-time analytics visualization

## Deployment
This app is configured for deployment on Vercel with zero configuration needed.
